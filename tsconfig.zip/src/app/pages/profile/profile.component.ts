import { CommonModule } from '@angular/common';
import { Component, OnInit, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import {  MatTableModule } from '@angular/material/table';
import { Router,  } from '@angular/router';


@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [FormsModule,MatTableModule, MatButtonModule,CommonModule],
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.css'
})
export class ProfileComponent implements OnInit {
  ngOnInit(): void {
    this.fetchSubmissions();
  }
  
  
  updateProfile() {
   this.router.navigateByUrl('update');
  }
  selectedCategory: string = 'household';


  router = inject(Router);
  user = JSON.parse(localStorage.getItem("user") || "null");
  userSubmissions: any;
  
  fetchSubmissions() {
    this.userSubmissions={
      household:[],
    transport : [],
    waste:[]
    };
    console.log(Number(this.user.id));
    

  

}

}
