import { Component, OnInit, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import {  MatTableModule } from '@angular/material/table';
import { UserService } from '../../services/user.service';
import { forkJoin } from 'rxjs';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-dash-board',
  standalone: true,
  imports: [CommonModule,MatButtonModule,MatTableModule],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashBoardComponent implements OnInit{
users: any;
viewSubmissions(userId: number) {
  this.showCategory('household');
  this.selectedUser={
    household:[],
    transport : [],
    waste:[]
  };
  
  
}

showCategory(category: string) {
  this.selectedCategory = category;
}

closeModal() {
  this.selectedUser = undefined;
  this.selectedCategory = null;
}
selectedCategory: any;
selectedUser: any;
  ngOnInit(): void {
    this.userService.getUsers().subscribe((res:any)=>{
      this.users= res.result;
    });
  }

  userService = inject(UserService);
 
  


}


