import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient) { }
  getUsers()
  {
    return this.http.get("https://projectapi.gerasim.in/api/UserApp/GetAllUsers");
  }
  
  login(userobj: any)
  {
    return this.http.post("https://localhost:7002/api/AuthApi/Login",userobj);
  }

  register(regobj: any)
  {
    return this.http.post("https://localhost:7002/api/AuthApi/Register",regobj);
  }

  update(id:Number,updateobj: any)
  {
    return this.http.put("https://localhost:7002/api/AuthApi/Update/4"+id,updateobj);
  }
}
